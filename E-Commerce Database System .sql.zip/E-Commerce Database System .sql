 -- Create database
CREATE DATABASE ecommerce_db;
USE ecommerce_db;

-- Users table
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);

-- Addresses table
CREATE TABLE addresses (
    address_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    address_line1 VARCHAR(100) NOT NULL,
    address_line2 VARCHAR(100),
    city VARCHAR(50) NOT NULL,
    state VARCHAR(50) NOT NULL,
    postal_code VARCHAR(20) NOT NULL,
    country VARCHAR(50) NOT NULL DEFAULT 'United States',
    is_default BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Categories table
CREATE TABLE categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    description TEXT,
    parent_category_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_category_id) REFERENCES categories(category_id) ON DELETE SET NULL
);

-- Products table
CREATE TABLE products (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    category_id INT,
    sku VARCHAR(50) UNIQUE,
    stock_quantity INT NOT NULL DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE SET NULL
);

-- Product images table
CREATE TABLE product_images (
    image_id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    image_url VARCHAR(255) NOT NULL,
    is_primary BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE
);

-- Orders table
CREATE TABLE orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
    total_amount DECIMAL(10, 2) NOT NULL,
    shipping_address_id INT,
    payment_method VARCHAR(50),
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (shipping_address_id) REFERENCES addresses(address_id)
);

-- Order items table
CREATE TABLE order_items (
    order_item_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- Inventory transactions table
CREATE TABLE inventory_transactions (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    quantity_change INT NOT NULL,
    transaction_type ENUM('purchase', 'sale', 'return', 'adjustment') NOT NULL,
    reference_id INT COMMENT 'order_id or purchase_id etc.',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- Reviews table
CREATE TABLE reviews (
    review_id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    user_id INT NOT NULL,
    rating TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Insert sample categories
INSERT INTO categories (name, description, parent_category_id) VALUES
('Electronics', 'Electronic devices and accessories', NULL),
('Computers', 'Computers and laptops', 1),
('Smartphones', 'Mobile phones and accessories', 1),
('Clothing', 'Apparel and fashion items', NULL),
('Men''s Clothing', 'Clothing for men', 4),
('Women''s Clothing', 'Clothing for women', 4);

-- Insert sample products
INSERT INTO products (name, description, price, category_id, sku, stock_quantity) VALUES
('Premium Laptop', 'High performance laptop with 16GB RAM and 1TB SSD', 1299.99, 2, 'LT-1001', 50),
('Smartphone Pro', 'Latest smartphone with 5G and 128GB storage', 899.99, 3, 'SP-2001', 100),
('Wireless Headphones', 'Noise cancelling wireless headphones', 199.99, 1, 'HP-3001', 75),
('Men''s Casual Shirt', 'Comfortable cotton shirt for men', 29.99, 5, 'CS-4001', 200),
('Women''s Summer Dress', 'Lightweight dress for summer', 49.99, 6, 'SD-5001', 150);

-- Insert sample users
INSERT INTO users (username, email, password_hash, first_name, last_name) VALUES
('john_doe', 'john@example.com', 'hashed_password_123', 'John', 'Doe'),
('jane_smith', 'jane@example.com', 'hashed_password_456', 'Jane', 'Smith');

-- Insert sample addresses
INSERT INTO addresses (user_id, address_line1, city, state, postal_code, is_default) VALUES
(1, '123 Main St', 'New York', 'NY', '10001', TRUE),
(2, '456 Oak Ave', 'Los Angeles', 'CA', '90001', TRUE);

-- 1. Sales by Category (Monthly)
SELECT 
    c.name AS category,
    DATE_FORMAT(o.order_date, '%Y-%m') AS month,
    SUM(oi.quantity * oi.unit_price) AS total_sales,
    COUNT(DISTINCT o.order_id) AS orders_count
FROM 
    orders o
JOIN 
    order_items oi ON o.order_id = oi.order_id
JOIN 
    products p ON oi.product_id = p.product_id
JOIN 
    categories c ON p.category_id = c.category_id
WHERE 
    o.status = 'delivered'
    AND o.order_date >= DATE_SUB(CURRENT_DATE, INTERVAL 6 MONTH)
GROUP BY 
    c.name, DATE_FORMAT(o.order_date, '%Y-%m')
ORDER BY 
    month DESC, total_sales DESC;

-- 2. Customer Lifetime Value
SELECT 
    u.user_id,
    u.username,
    COUNT(o.order_id) AS total_orders,
    SUM(o.total_amount) AS total_spent,
    AVG(o.total_amount) AS avg_order_value,
    MIN(o.order_date) AS first_order_date,
    MAX(o.order_date) AS last_order_date
FROM 
    users u
LEFT JOIN 
    orders o ON u.user_id = o.user_id
GROUP BY 
    u.user_id, u.username
ORDER BY 
    total_spent DESC;

-- 3. Inventory Health Report
SELECT 
    p.product_id,
    p.name,
    p.stock_quantity,
    c.name AS category,
    SUM(CASE WHEN it.transaction_type = 'sale' THEN it.quantity_change ELSE 0 END) AS sold_last_30_days,
    (p.stock_quantity / NULLIF(SUM(CASE WHEN it.transaction_type = 'sale' THEN ABS(it.quantity_change) ELSE 0 END), 0)) AS months_of_inventory
FROM 
    products p
JOIN 
    categories c ON p.category_id = c.category_id
LEFT JOIN 
    inventory_transactions it ON p.product_id = it.product_id
    AND it.created_at >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY)
GROUP BY 
    p.product_id, p.name, p.stock_quantity, c.name
ORDER BY 
    months_of_inventory ASC;

-- 4. Product Performance with Reviews
SELECT 
    p.product_id,
    p.name,
    p.price,
    COUNT(DISTINCT oi.order_id) AS times_ordered,
    SUM(oi.quantity) AS units_sold,
    AVG(r.rating) AS avg_rating,
    COUNT(r.review_id) AS review_count
FROM 
    products p
LEFT JOIN 
    order_items oi ON p.product_id = oi.product_id
LEFT JOIN 
    orders o ON oi.order_id = o.order_id AND o.status = 'delivered'
LEFT JOIN 
    reviews r ON p.product_id = r.product_id
GROUP BY 
    p.product_id, p.name, p.price
ORDER BY 
    units_sold DESC;

-- 5. Monthly Revenue Growth
SELECT 
    DATE_FORMAT(order_date, '%Y-%m') AS month,
    SUM(total_amount) AS revenue,
    LAG(SUM(total_amount), 1) OVER (ORDER BY DATE_FORMAT(order_date, '%Y-%m')) AS prev_month_revenue,
    (SUM(total_amount) - LAG(SUM(total_amount), 1) OVER (ORDER BY DATE_FORMAT(order_date, '%Y-%m'))) / 
    LAG(SUM(total_amount), 1) OVER (ORDER BY DATE_FORMAT(order_date, '%Y-%m')) * 100 AS growth_percentage
FROM 
    orders
WHERE 
    status = 'delivered'
    AND order_date >= DATE_SUB(CURRENT_DATE, INTERVAL 12 MONTH)
GROUP BY 
    DATE_FORMAT(order_date, '%Y-%m')
ORDER BY 
    month;
    
    
-- 1. Place Order Procedure
DELIMITER //
CREATE PROCEDURE place_order(
    IN p_user_id INT,
    IN p_shipping_address_id INT,
    IN p_payment_method VARCHAR(50),
    OUT p_order_id INT
)
BEGIN
    DECLARE v_total DECIMAL(10, 2) DEFAULT 0;
    DECLARE v_cart_item_count INT DEFAULT 0;
    
    -- Start transaction
    START TRANSACTION;
    
    -- Calculate total from cart (assuming cart items are in a temporary table)
    SELECT SUM(quantity * price) INTO v_total
    FROM temp_cart
    JOIN products ON temp_cart.product_id = products.product_id
    WHERE temp_cart.user_id = p_user_id;
    
    SELECT COUNT(*) INTO v_cart_item_count FROM temp_cart WHERE user_id = p_user_id;
    
    IF v_cart_item_count = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cart is empty';
        ROLLBACK;
    ELSE
        -- Create order
        INSERT INTO orders (user_id, total_amount, shipping_address_id, payment_method)
        VALUES (p_user_id, v_total, p_shipping_address_id, p_payment_method);
        
        SET p_order_id = LAST_INSERT_ID();
        
        -- Add order items
        INSERT INTO order_items (order_id, product_id, quantity, unit_price)
        SELECT 
            p_order_id, 
            temp_cart.product_id, 
            temp_cart.quantity, 
            products.price
        FROM temp_cart
        JOIN products ON temp_cart.product_id = products.product_id
        WHERE temp_cart.user_id = p_user_id;
        
        -- Update inventory
        INSERT INTO inventory_transactions (product_id, quantity_change, transaction_type, reference_id)
        SELECT 
            product_id, 
            -quantity, 
            'sale', 
            p_order_id
        FROM temp_cart
        WHERE user_id = p_user_id;
        
        -- Update product stock
        UPDATE products p
        JOIN temp_cart tc ON p.product_id = tc.product_id
        SET p.stock_quantity = p.stock_quantity - tc.quantity
        WHERE tc.user_id = p_user_id;
        
        -- Clear cart
        DELETE FROM temp_cart WHERE user_id = p_user_id;
        
        COMMIT;
    END IF;
END //
DELIMITER ;

-- 2. Get Product Recommendations
DELIMITER //
CREATE PROCEDURE get_product_recommendations(
    IN p_user_id INT,
    IN p_limit INT
)
BEGIN
    -- Based on user's order history
    SELECT 
        p.product_id,
        p.name,
        p.price,
        AVG(r.rating) AS avg_rating
    FROM 
        products p
    LEFT JOIN 
        reviews r ON p.product_id = r.product_id
    WHERE 
        p.category_id IN (
            SELECT DISTINCT p2.category_id
            FROM order_items oi
            JOIN orders o ON oi.order_id = o.order_id
            JOIN products p2 ON oi.product_id = p2.product_id
            WHERE o.user_id = p_user_id
        )
        AND p.product_id NOT IN (
            SELECT oi.product_id
            FROM order_items oi
            JOIN orders o ON oi.order_id = o.order_id
            WHERE o.user_id = p_user_id
        )
    GROUP BY 
        p.product_id, p.name, p.price
    ORDER BY 
        avg_rating DESC
    LIMIT p_limit;
END //
DELIMITER ;